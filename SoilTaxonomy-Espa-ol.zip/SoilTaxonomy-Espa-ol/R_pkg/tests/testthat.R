library(testthat)
library(SoilTaxonomy)

test_check("SoilTaxonomy")
