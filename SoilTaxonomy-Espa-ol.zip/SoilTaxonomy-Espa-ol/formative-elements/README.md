

Convert subgroup level tax into a stem-plot like output with plain language explanation.

use formative elements / simple connotative desc.

```
typic haploxerolls
|     |    |  |
|     |    |  |
average    |  |
      |    |  |
	    average |
	         |  |
		   xeric SMR
		       |
			    surface accumulation of organic material
```		  
			  
			  
https://en.wikipedia.org/wiki/Sentence_diagram

https://stackoverflow.com/questions/33473107/visualize-parse-tree-structure

